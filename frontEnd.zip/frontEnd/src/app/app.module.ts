import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule } from '@angular/common/http';
import { FrameworksComponent } from './frameworks/frameworks.component';
import { AddFrameworkComponent } from './addframework/addframework.component';
import { EditFrameworkComponent } from './editframework/editframework.component';

import {MatToolbarModule, MatCheckboxModule, MatMenuModule, MatButtonModule, MatIconModule, MatListModule, MatDialogModule, MatInputModule } from '@angular/material';

import {FormsModule} from '@angular/forms';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {MatFormFieldModule} from '@angular/material/form-field';


@NgModule({
  declarations: [
    AppComponent,
    FrameworksComponent,
    AddFrameworkComponent,
    EditFrameworkComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    MatButtonModule,
    MatCheckboxModule,
    MatMenuModule,
    MatListModule,
    MatFormFieldModule,
    MatDialogModule,
    MatInputModule,
    FormsModule,
    MatIconModule,
    BrowserAnimationsModule
  ],
  entryComponents: [AddFrameworkComponent, EditFrameworkComponent],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }