package pl.edu.wszib.solszews.spring.controller;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import pl.edu.wszib.solszews.spring.Auth;

import pl.edu.wszib.solszews.spring.Auth;

@CrossOrigin(origins = "http://localhost:4200")
@Controller
public class UserController
{
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity getLoginData(@RequestParam("username") String username, @RequestParam("pass") String pass)
    {
        Boolean login_result;  //to jest żałosne, że nie mogę zadeklarować w try oraz w catch.
        try
        {
            login_result = Auth.login(username, pass);
        }
        catch (Exception e)
        {
            System.out.println(e.toString());
            login_result = false;
        }
        if (login_result)
        {
            return new ResponseEntity<>(Auth.getToken(), HttpStatus.OK);
        }
        else
        {
            return new ResponseEntity<>("Could not log in. Please use PHP", HttpStatus.BAD_REQUEST);
        }
    }
}
