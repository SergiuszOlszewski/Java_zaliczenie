package pl.edu.wszib.solszews.spring;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import pl.edu.wszib.solszews.spring.model.Framework;

public class SpringRestClient {

    private static final String GET_FRAMEWORKS_ENDPOINT_URL = "http://localhost:8080/api/v1/frameworks";
    private static final String GET_FRAMEWORK_ENDPOINT_URL = "http://localhost:8080/api/v1/frameworks/{id}";
    private static final String CREATE_FRAMEWORK_ENDPOINT_URL = "http://localhost:8080/api/v1/frameworks";
    private static final String UPDATE_FRAMEWORK_ENDPOINT_URL = "http://localhost:8080/api/v1/frameworks/{id}";
    private static final String DELETE_FRAMEWORK_ENDPOINT_URL = "http://localhost:8080/api/v1/frameworks/{id}";
    private static RestTemplate restTemplate = new RestTemplate();

    public static void main(String[] args) {
        SpringRestClient springRestClient = new SpringRestClient();

        // Step1: first create a new framework
        springRestClient.createFramework();

        // Step 2: get new created framework from step1
        springRestClient.getFrameworkById();

        // Step3: get all frameworks
        springRestClient.getFrameworks();

        // Step4: Update framework with id = 1
        springRestClient.updateFramework();

        // Step5: Delete framework with id = 1
        springRestClient.deleteFramework();
    }

    private void getFrameworks() {

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

        ResponseEntity<String> result = restTemplate.exchange(GET_FRAMEWORKS_ENDPOINT_URL, HttpMethod.GET, entity,
                String.class);

        System.out.println(result);
    }

    private void getFrameworkById() {

        Map<String, String> params = new HashMap<String, String>();
        params.put("id", "1");

        RestTemplate restTemplate = new RestTemplate();
        Framework result = restTemplate.getForObject(GET_FRAMEWORK_ENDPOINT_URL, Framework.class, params);

        System.out.println(result);
    }

    private void createFramework() {

        Framework newFramework = new Framework("Laravel", "PHP", 6);

        RestTemplate restTemplate = new RestTemplate();
        Framework result = restTemplate.postForObject(CREATE_FRAMEWORK_ENDPOINT_URL, newFramework, Framework.class);

        System.out.println(result);
    }

    private void updateFramework() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("id", "1");
        Framework updatedFramework = new Framework("Laravel", "PHP", 6);
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.put(UPDATE_FRAMEWORK_ENDPOINT_URL, updatedFramework, params);
    }

    private void deleteFramework() {
        Map<String, String> params = new HashMap<String, String>();
        params.put("id", "1");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(DELETE_FRAMEWORK_ENDPOINT_URL, params);
    }


}

