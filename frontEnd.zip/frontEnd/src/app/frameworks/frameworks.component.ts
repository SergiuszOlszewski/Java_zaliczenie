import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Framework } from './frameworkModel';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { EditFrameworkComponent } from '../editframework/editframework.component';

@Component({
  selector: 'app-frameworks',
  templateUrl: './frameworks.component.html',
  styleUrls: ['./frameworks.component.css']
})
export class FrameworksComponent implements OnInit {
  frameworks: Framework[];
  show: boolean = true;

  constructor(private apiService: ApiService, public dialog: MatDialog) { 
    
  }

  ngOnInit() {
    this.getFrameworks();

    
  }

  getFrameworks(){
    this.apiService.getFrameworks()
      .subscribe(
        (data: Framework[]) =>  {
          this.frameworks = data;
          if(this.frameworks.length > 0)
            this.show = false;
          else
            this.show = true;
        }, 
        (error: any)   => console.log(error),
        ()             => console.log('all data gets')
      );
  }


  deleteItem(_id: number){
    this.apiService.deleteFramework(_id)
      .subscribe(
        (res: any) => this.getFrameworks(), 
        (error: any) => console.log(error), 
        () => console.log('deleted') 
      )
  }

  openEditDialog(_id): void {
    //console.log(_id);
    this.apiService.getFramework(_id)
        .subscribe( 
          (resp: Framework) => {
            const dialogConfig = new MatDialogConfig();
            dialogConfig.width = '500px';
            dialogConfig.data = resp;
            const dialogRef = this.dialog.open(EditFrameworkComponent, dialogConfig);

            dialogRef.afterClosed().subscribe(result => {
              console.log('The dialog was closed');
            });
          },
          (error: any) => console.log(error),
          ()=> console.log('complete')
        );
  }
}

