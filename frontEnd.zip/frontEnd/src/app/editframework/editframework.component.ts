import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { ApiService } from '../api.service';
import { Framework } from './../frameworks/frameworkModel';


@Component({
  selector: 'app-editframework',
  templateUrl: './editframework.component.html',
})
export class EditFrameworkComponent  implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<EditFrameworkComponent>,
    @Inject(MAT_DIALOG_DATA) public passingData: Framework,
    private apiService: ApiService
  ){}

  frameworks = [];

    ngOnInit() {
        // this.apiService.getFrameworks()
        // .subscribe(
        //   (data: Framework[]) =>  this.frameworks = data,
        //   (error: any)   => console.log(error)
        // );
    }

    onCancel(): void {
      this.dialogRef.close();
    }
    
    onSave(formData: any){
      let _framework: any = {_id: formData.id, name: formData.name, language: formData.language, rating: formData.rating };
      this.apiService.updateFramework(_framework)
        .subscribe(
          (data: Framework) => location.reload(),
          (error) => console.log(error)
        );
      this.dialogRef.close();
    }

}

