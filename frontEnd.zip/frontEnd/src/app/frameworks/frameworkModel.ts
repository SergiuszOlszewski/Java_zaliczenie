export class Framework {
    id: number;
    name = '';
    language = '';
    rating: number;
  
    constructor(values: Object = {}) {
      Object.assign(this, values);
    }
  }