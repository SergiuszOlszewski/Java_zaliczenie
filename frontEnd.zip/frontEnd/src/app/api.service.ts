import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Framework } from './frameworks/frameworkModel';
import { Observable } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { HttpHeaders } from '@angular/common/http';
const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'token': 'H5HA775US4UI4JHUGH878JG5UI4NT4IOV3J8CM893YU'
  })
};

@Injectable({
  providedIn: 'root'
})
export class ApiService {


  base_url: string = 'http://localhost:8080/api/v1';


  
  constructor(private http: HttpClient) { }

  // public getFrameworks(){
  //   return this.httpClient.get(`http://localhost:8080/api/v1/frameworks`);
  // }

  getFrameworks(): Observable<Framework[]>{
       return this.http.get<Framework[]>(`${this.base_url}/frameworks`);
}


  getFramework(_id: number): Observable<Framework>{
    return this.http.get<Framework>(`${this.base_url}/frameworks/${_id}`);
}


addFramework(_framework:Framework): Observable<Framework>{
  return this.http.post<Framework>(`${this.base_url}/frameworks`, _framework, {
      headers: {
          'Content-Type': 'application/json'
      }
  });
}

  updateFramework(_framework:Framework): Observable<Framework>{
    return this.http.put<Framework>(`${this.base_url}/frameworks/${_framework.id}`, 
    _framework, {
        headers: {
            'Content-Type': 'application/json'
        }
    });
}

  deleteFramework(_id:number): Observable<Framework>{
    return this.http.delete<Framework>(`${this.base_url}/frameworks/${_id}`, httpOptions);
}

}
