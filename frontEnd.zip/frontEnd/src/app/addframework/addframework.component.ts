import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { ApiService } from '../api.service';
import { Framework } from './../frameworks/frameworkModel';


@Component({
  selector: 'app-addframework',
  templateUrl: './addframework.component.html',
})
export class AddFrameworkComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<AddFrameworkComponent>,
    private apiService: ApiService
  ){}

  frameworks = [];

    ngOnInit() {
        this.apiService.getFrameworks()
        .subscribe(
          (data: Framework[]) =>  this.frameworks = data,
          (error: any)   => console.log(error)
        );
    }

    onCancel(): void {
      this.dialogRef.close();
    }
    
    onSave(formData: any){
      let _framework: any = { name: formData.name, language: formData.language, rating: formData.rating };
      this.apiService.addFramework(_framework)
        .subscribe(
          (data: Framework) => location.reload(),
          (error) => console.log(error)
        );
      this.dialogRef.close();
    }

}

