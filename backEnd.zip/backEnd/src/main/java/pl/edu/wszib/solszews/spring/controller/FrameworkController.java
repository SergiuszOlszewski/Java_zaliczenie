package pl.edu.wszib.solszews.spring.controller;

import java.util.HashMap;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import pl.edu.wszib.solszews.spring.Auth;
import pl.edu.wszib.solszews.spring.exception.ResourceNotFoundException;
import pl.edu.wszib.solszews.spring.model.Framework;
import pl.edu.wszib.solszews.spring.repository.FrameworkRepository;

import pl.edu.wszib.solszews.spring.Auth;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class FrameworkController
{
    @Autowired
    private FrameworkRepository frameworkRepository;

    @GetMapping("/frameworks")
    public List<Framework> getAllFrameworks()
    {
        return frameworkRepository.findAll();
    }

    @GetMapping("/frameworks/{id}")
    public ResponseEntity<Framework> getFrameworkById(@PathVariable(value = "id") Long frameworkId)
            throws ResourceNotFoundException
    {
        Framework framework = frameworkRepository.findById(frameworkId)
                .orElseThrow(() -> new ResourceNotFoundException("Brak obiektu o podanym ID: " + frameworkId));
        return ResponseEntity.ok().body(framework);
    }

    @PostMapping("/frameworks")
    public Framework createFramework(@Valid @RequestBody Framework framework)
    {
        if(framework.getName().equals("Spring") && framework.getRating() > 0)
            throw new IllegalArgumentException("Ocena Springa nie może być wyższa od 0");
        return frameworkRepository.save(framework);
    }

    @PutMapping("/frameworks/{id}")
    public ResponseEntity<Framework> updateFramework(@PathVariable(value = "id") Long frameworkId, @Valid @RequestBody Framework frameworkDetails)
            throws ResourceNotFoundException
    {
        Framework framework = frameworkRepository.findById(frameworkId)
                .orElseThrow(() -> new ResourceNotFoundException("Brak obiektu o podanym ID: " + frameworkId));

        framework.setRating(frameworkDetails.getRating());
        framework.setName(frameworkDetails.getName());
        framework.setLanguage(frameworkDetails.getLanguage());
        final Framework updatedFramework = frameworkRepository.save(framework);
        return ResponseEntity.ok(updatedFramework);
    }

    @DeleteMapping("/frameworks/{id}")
    public Map<String, Boolean> deleteFramework(@PathVariable(value = "id") Long frameworkId, @RequestHeader("token") String token) //dałbym wartość domyślną tokena na "nope", ale oczywiście java nie ma wartości domyślnych.
            throws ResourceNotFoundException
    {
        Map<String, Boolean> response = new HashMap<>();
        if(Auth.compareToken(token))
        {
            Framework framework = frameworkRepository.findById(frameworkId).orElseThrow(() -> new ResourceNotFoundException("Brak obiektu o podanym ID: " + frameworkId));
            frameworkRepository.delete(framework);
            response.put("deleted", Boolean.TRUE);
            return response;
        }
        response.put("no auth", Boolean.FALSE);
        return response;
    }
}


