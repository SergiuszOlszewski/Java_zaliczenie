package pl.edu.wszib.solszews.spring;

import org.springframework.util.DigestUtils;

import java.security.MessageDigest;

public class Auth {
    static String token;

    public static Boolean login(String username, String password)
    {
        String hashed_password = password+"a w PHP da sie hashowac hasla"; //Żałosne. Dodanie kilku linijek kodu do wbudowanych bibliotek javy jest zbyt trudne. Sprawdziłem: DigestUtils, MessageDigest, Hashing.sha1() oraz inne. Nic nie działa. Dla porównania w PHP: sha1($pass);
        if(username.equals("admin") && hashed_password.equals("ala123a w PHP da sie hashowac hasla"))
        {
            token="H5HA775US4UI4JHUGH878JG5UI4NT4IOV3J8CM893YU"; //tutaj generowałbym losowy kod dla sesji, ale w Javie to jakiś tydzień klepania kodu. Dla porównania w PHP md5($username.$pass.rand(0, MAX_INT).GLOBAL_SITE_SALT);
            return true;
        }
        return false;
    }
    public static String getToken()
    {
        return token;
    }

    public static Boolean compareToken(String _code)
    {
        return token.equals(_code); //Nigdy ie wolno robić czegoś takiego! Zawsze należy porównywać hashe. Ale w javie nie ma hashy, więc nie ma nawet resztek bezpieczeństwa. Atak timingowy murowany.
    }
}
