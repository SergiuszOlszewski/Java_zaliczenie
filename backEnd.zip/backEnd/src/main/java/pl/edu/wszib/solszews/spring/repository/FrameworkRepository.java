package pl.edu.wszib.solszews.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import pl.edu.wszib.solszews.spring.model.Framework;

@Repository
public interface FrameworkRepository extends JpaRepository<Framework, Long>{

}
