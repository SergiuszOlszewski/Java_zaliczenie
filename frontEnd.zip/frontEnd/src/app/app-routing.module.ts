import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FrameworksComponent } from './frameworks/frameworks.component';

const routes: Routes = [
  {path:'', component: FrameworksComponent}  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
